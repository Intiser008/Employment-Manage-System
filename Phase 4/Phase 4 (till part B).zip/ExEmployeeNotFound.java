
public class ExEmployeeNotFound extends Exception{
    public ExEmployeeNotFound(String exMsg){
        super(exMsg);
    }
}
