
public class ExTeamAlreadyExists extends Exception{
    public ExTeamAlreadyExists(String exMsg){
        super(exMsg);
    }
}
