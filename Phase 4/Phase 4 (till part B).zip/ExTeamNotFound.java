
public class ExTeamNotFound extends Exception{
    public ExTeamNotFound(String exMsg){
        super(exMsg);
    }
}
