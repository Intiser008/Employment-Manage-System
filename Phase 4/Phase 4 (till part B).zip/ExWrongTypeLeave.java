
public class ExWrongTypeLeave extends Exception{
    public ExWrongTypeLeave(String exMsg){
        super(exMsg);
    }
}
