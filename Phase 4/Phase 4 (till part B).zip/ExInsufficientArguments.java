
public class ExInsufficientArguments extends Exception{

    public ExInsufficientArguments(String exMsg) {
        super(exMsg);
    }

}
