
public class ExAlreadyMember extends Exception{
    public ExAlreadyMember(String exMsg){
        super(exMsg);
    }
}
