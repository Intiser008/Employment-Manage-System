
public class ExOutOfLeaves extends Exception{
    public ExOutOfLeaves(String exMsg){
        super(exMsg);
    }
}
