
public class ExEmployeeAlreadyExists extends Exception{
    public ExEmployeeAlreadyExists(String exMsg){
        super(exMsg);
    }
}
