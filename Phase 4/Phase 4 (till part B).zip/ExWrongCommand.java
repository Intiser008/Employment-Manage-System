
public class ExWrongCommand extends Exception{
    public ExWrongCommand(String exMsg){
        super(exMsg);
    }
}
