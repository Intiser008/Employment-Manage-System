
public class ExLeaveOutOfRange extends Exception{
    public ExLeaveOutOfRange(String exMsg){
        super(exMsg);
    }
}
